import { Routes } from '@angular/router';
import { ArrOfObjectsCrudComponent } from './arr_of_objects_crud/arr-of-objects-crud.component';
import { FormEventsComponent } from './form_events/form-events.component';
import { CrudOperationsComponent } from './crudoperations/crud-operations.component';
import { StructuralDirectivesComponent } from './structural_directives/structural-directives.component';

export const routes: Routes = [
    {
        path:'Resume',
        component:FormEventsComponent
    },
    {
        path:'crud-operations',
        component:CrudOperationsComponent
    },
    {
        path:' arr_of_objects',
        component:ArrOfObjectsCrudComponent
    },
    {
        path:'stuctural_directives',
        component:StructuralDirectivesComponent
    }
];
